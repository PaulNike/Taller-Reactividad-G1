package com.talleresdeprogramacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringReactorApplicationTests {

	@Test
	void contextLoads() {
	}

}
